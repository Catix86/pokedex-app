export interface PokemonListItem {
  name: string;
  url: string;
  id: number;
  sprite: string;
  types: string[];
}

export interface PokemonDetail {
  id: number;
  name: string;
  height: number;         // in decimetri
  weight: number;         // in ettogrammi
  base_experience: number;
  sprites: PokemonSprites;
  types: PokemonTypeSlot[];
  stats: PokemonStatSlot[];
  abilities: PokemonAbilitySlot[];
  moves: PokemonMoveSlot[];
  species: { name: string; url: string };
  forms: { name: string; url: string }[];
}

export interface PokemonSprites {
  front_default: string;
  back_default: string;
  front_shiny: string;
  back_shiny: string;
  other: {
    'official-artwork': {
      front_default: string;
      front_shiny: string;
    };
    dream_world: {
      front_default: string;
    };
  };
}

export interface PokemonTypeSlot {
  slot: number;
  type: { name: string; url: string };
}

export interface PokemonStatSlot {
  base_stat: number;
  effort: number;
  stat: { name: string; url: string };
}

export interface PokemonAbilitySlot {
  is_hidden: boolean;
  slot: number;
  ability: { name: string; url: string };
}

export interface PokemonMoveSlot {
  move: { name: string; url: string };
}

export interface PokemonSpecies {
  flavor_text_entries: FlavorTextEntry[];
  genera: Genus[];
  generation: { name: string; url: string };
  habitat: { name: string; url: string } | null;
  is_legendary: boolean;
  is_mythical: boolean;
  evolves_from_species: { name: string; url: string } | null;
  color: { name: string; url: string };
  shape: { name: string; url: string };
}

export interface FlavorTextEntry {
  flavor_text: string;
  language: { name: string; url: string };
  version: { name: string; url: string };
}

export interface Genus {
  genus: string;
  language: { name: string; url: string };
}

// Colori per tipo Pokémon
export const TYPE_COLORS: Record<string, string> = {
  normal:   '#A8A878',
  fire:     '#F08030',
  water:    '#6890F0',
  electric: '#F8D030',
  grass:    '#78C850',
  ice:      '#98D8D8',
  fighting: '#C03028',
  poison:   '#A040A0',
  ground:   '#E0C068',
  flying:   '#A890F0',
  psychic:  '#F85888',
  bug:      '#A8B820',
  rock:     '#B8A038',
  ghost:    '#705898',
  dragon:   '#7038F8',
  dark:     '#705848',
  steel:    '#B8B8D0',
  fairy:    '#EE99AC',
};

export const STAT_LABELS: Record<string, string> = {
  'hp':              'HP',
  'attack':          'Attacco',
  'defense':         'Difesa',
  'special-attack':  'Att. Spec.',
  'special-defense': 'Dif. Spec.',
  'speed':           'Velocità',
};

export const GENERATIONS: Record<string, string> = {
  'generation-i':    'Gen I (Kanto)',
  'generation-ii':   'Gen II (Johto)',
  'generation-iii':  'Gen III (Hoenn)',
  'generation-iv':   'Gen IV (Sinnoh)',
  'generation-v':    'Gen V (Unova)',
  'generation-vi':   'Gen VI (Kalos)',
  'generation-vii':  'Gen VII (Alola)',
  'generation-viii': 'Gen VIII (Galar)',
  'generation-ix':   'Gen IX (Paldea)',
};
