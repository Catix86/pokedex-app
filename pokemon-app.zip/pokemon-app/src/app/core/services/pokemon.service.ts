import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, forkJoin, map, switchMap, tap, of } from 'rxjs';
import {
  PokemonDetail,
  PokemonListItem,
  PokemonSpecies,
} from '../models/pokemon.model';

const API_BASE = 'https://pokeapi.co/api/v2';
const TOTAL_POKEMON = 1025; // fino a Gen IX

@Injectable({ providedIn: 'root' })
export class PokemonService {
  private http = inject(HttpClient);

  // Cache in memoria per evitare chiamate ripetute
  private listCache: PokemonListItem[] | null = null;
  private detailCache = new Map<number, PokemonDetail>();
  private speciesCache = new Map<number, PokemonSpecies>();

  /** Carica la lista completa dei Pokémon con sprite e tipi */
  getAllPokemon(): Observable<PokemonListItem[]> {
    if (this.listCache) {
      return of(this.listCache);
    }

    return this.http
      .get<{ results: { name: string; url: string }[] }>(
        `${API_BASE}/pokemon?limit=${TOTAL_POKEMON}&offset=0`
      )
      .pipe(
        map((res) =>
          res.results.map((p, i) => {
            const id = this.extractIdFromUrl(p.url);
            return {
              name: p.name,
              url: p.url,
              id,
              sprite: this.getSpriteUrl(id),
              types: [], // popolati lazy
            };
          })
        ),
        tap((list) => (this.listCache = list))
      );
  }

  /** Dettaglio completo di un singolo Pokémon */
  getPokemonDetail(id: number): Observable<PokemonDetail> {
    if (this.detailCache.has(id)) {
      return of(this.detailCache.get(id)!);
    }

    return this.http
      .get<PokemonDetail>(`${API_BASE}/pokemon/${id}`)
      .pipe(tap((p) => this.detailCache.set(id, p)));
  }

  /** Dati della specie (descrizione, generazione, ecc.) */
  getPokemonSpecies(id: number): Observable<PokemonSpecies> {
    if (this.speciesCache.has(id)) {
      return of(this.speciesCache.get(id)!);
    }

    return this.http
      .get<PokemonSpecies>(`${API_BASE}/pokemon-species/${id}`)
      .pipe(tap((s) => this.speciesCache.set(id, s)));
  }

  /** Carica dettaglio + specie insieme */
  getPokemonFull(
    id: number
  ): Observable<{ detail: PokemonDetail; species: PokemonSpecies }> {
    return this.getPokemonDetail(id).pipe(
      switchMap((detail) =>
        this.getPokemonSpecies(id).pipe(
          map((species) => ({ detail, species }))
        )
      )
    );
  }

  /** Carica i tipi di un batch di Pokémon (usato per pre-populate la lista) */
  enrichWithTypes(items: PokemonListItem[]): Observable<PokemonListItem[]> {
    const requests = items.map((item) =>
      this.getPokemonDetail(item.id).pipe(
        map((detail) => ({
          ...item,
          types: detail.types.map((t) => t.type.name),
        }))
      )
    );
    return forkJoin(requests);
  }

  private extractIdFromUrl(url: string): number {
    const parts = url.split('/').filter(Boolean);
    return parseInt(parts[parts.length - 1], 10);
  }

  getSpriteUrl(id: number): string {
    return `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${id}.png`;
  }

  formatName(name: string): string {
    return name
      .split('-')
      .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
      .join(' ');
  }

  padId(id: number): string {
    return id.toString().padStart(4, '0');
  }
}
