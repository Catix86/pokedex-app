import { Component, Input } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { PokemonListItem, TYPE_COLORS } from '../../core/models/pokemon.model';
import { PokemonService } from '../../core/services/pokemon.service';

@Component({
  selector: 'app-pokemon-card',
  standalone: true,
  imports: [RouterLink, CommonModule],
  template: `
    <a class="card" [routerLink]="['/pokemon', pokemon.id]">
      <div class="card-bg" [style.background]="cardGradient"></div>

      <span class="card-id">#{{ service.padId(pokemon.id) }}</span>

      <div class="card-img-wrap">
        <img
          [src]="pokemon.sprite"
          [alt]="pokemon.name"
          class="card-img"
          loading="lazy"
          (error)="onImgError($event)"
        />
      </div>

      <div class="card-body">
        <h3 class="card-name">{{ service.formatName(pokemon.name) }}</h3>
        <div class="card-types">
          <span
            *ngFor="let type of pokemon.types"
            class="type-badge"
            [style.background]="getTypeColor(type)"
          >{{ type }}</span>
        </div>
      </div>
    </a>
  `,
  styleUrl: './pokemon-card.component.scss',
})
export class PokemonCardComponent {
  @Input({ required: true }) pokemon!: PokemonListItem;

  constructor(public service: PokemonService) {}

  get cardGradient(): string {
    if (!this.pokemon.types.length) return 'linear-gradient(135deg, #1a1a2e, #16213e)';
    const c1 = TYPE_COLORS[this.pokemon.types[0]] ?? '#888';
    const c2 = this.pokemon.types[1] ? (TYPE_COLORS[this.pokemon.types[1]] ?? c1) : c1;
    return `linear-gradient(135deg, ${c1}33, ${c2}55)`;
  }

  getTypeColor(type: string): string {
    return TYPE_COLORS[type] ?? '#888';
  }

  onImgError(event: Event): void {
    const img = event.target as HTMLImageElement;
    img.src = `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${this.pokemon.id}.png`;
  }
}
