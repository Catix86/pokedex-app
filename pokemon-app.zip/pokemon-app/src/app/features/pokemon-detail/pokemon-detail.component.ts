import { Component, OnInit, inject, signal, ChangeDetectionStrategy } from '@angular/core';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { switchMap } from 'rxjs';
import { PokemonService } from '../../core/services/pokemon.service';
import {
  PokemonDetail,
  PokemonSpecies,
  TYPE_COLORS,
  STAT_LABELS,
  GENERATIONS,
} from '../../core/models/pokemon.model';

@Component({
  selector: 'app-pokemon-detail',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, RouterLink],
  templateUrl: './pokemon-detail.component.html',
  styleUrl: './pokemon-detail.component.scss',
})
export class PokemonDetailComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  public svc = inject(PokemonService);

  detail = signal<PokemonDetail | null>(null);
  species = signal<PokemonSpecies | null>(null);
  loading = signal(true);
  error = signal<string | null>(null);
  showShiny = signal(false);

  readonly TYPE_COLORS = TYPE_COLORS;
  readonly STAT_LABELS = STAT_LABELS;
  readonly GENERATIONS = GENERATIONS;

  ngOnInit(): void {
    this.route.paramMap
      .pipe(
        switchMap((params) => {
          const id = Number(params.get('id'));
          return this.svc.getPokemonFull(id);
        })
      )
      .subscribe({
        next: ({ detail, species }) => {
          this.detail.set(detail);
          this.species.set(species);
          this.loading.set(false);
        },
        error: () => {
          this.error.set('Pokemon non trovato.');
          this.loading.set(false);
        },
      });
  }

  goBack(): void {
    this.router.navigate(['/pokemon']);
  }

  goToId(offset: number): void {
    const current = this.detail()?.id ?? 1;
    const next = Math.max(1, Math.min(1025, current + offset));
    this.loading.set(true);
    this.detail.set(null);
    this.species.set(null);
    this.router.navigate(['/pokemon', next]);
  }

  toggleShiny(): void {
    this.showShiny.update((v) => !v);
  }

  getFlavorText(): string {
    const entries = this.species()?.flavor_text_entries ?? [];
    const it = entries.find((e) => e.language.name === 'it');
    const en = entries.find((e) => e.language.name === 'en');
    const raw = (it ?? en)?.flavor_text ?? '';
    return raw.replace(/[\n\f\r]/g, ' ');
  }

  getGenus(): string {
    const genera = this.species()?.genera ?? [];
    const it = genera.find((g) => g.language.name === 'it');
    const en = genera.find((g) => g.language.name === 'en');
    return (it ?? en)?.genus ?? '';
  }

  getGeneration(): string {
    const gen = this.species()?.generation?.name ?? '';
    return this.GENERATIONS[gen] ?? gen;
  }

  getMainSprite(): string {
    const d = this.detail();
    if (!d) return '';
    if (this.showShiny()) {
      return d.sprites.other['official-artwork'].front_shiny ?? d.sprites.front_shiny;
    }
    return d.sprites.other['official-artwork'].front_default ?? d.sprites.front_default;
  }

  getStatPercent(base: number): number {
    return Math.min(100, Math.round((base / 255) * 100));
  }

  getStatColor(base: number): string {
    if (base >= 150) return '#a855f7';
    if (base >= 100) return '#22c55e';
    if (base >= 70)  return '#eab308';
    if (base >= 40)  return '#f97316';
    return '#ef4444';
  }

  getTypeColor(type: string): string {
    return TYPE_COLORS[type] ?? '#888';
  }

  get heightM(): string {
    return ((this.detail()?.height ?? 0) / 10).toFixed(1);
  }

  get weightKg(): string {
    return ((this.detail()?.weight ?? 0) / 10).toFixed(1);
  }

  get totalStats(): number {
    return (this.detail()?.stats ?? []).reduce((sum, s) => sum + s.base_stat, 0);
  }

  onImgError(event: Event): void {
    const img = event.target as HTMLImageElement;
    const d = this.detail();
    if (d) img.src = `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${d.id}.png`;
  }
}
